from django.urls import path 
from . import views
urlpatterns=[
    path('',views.home,name='name'),
    path('contact/',views.contact,name='conatct'),
    path('about/',views.about,name='about'),
    path('feedback/',views.feedback,name='feedback'),
    path('vet/',views.vet,name='vet'),
    path('Petra/',views.Petra,name='Petra'),
    path('taj/',views.taj,name='taj'),
    path('ci/',views.ci,name='ci'),
    path('mp/',views.mp,name='mp'),
    path('cht/',views.cht,name='cht'),
    path('christ/',views.christ,name='christ'),


]