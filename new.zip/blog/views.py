from django.shortcuts import render

def home(request):
    return render(request,'home.html')
def contact(request):
    return render(request,'contact.html')
def about(request):
    return render(request,'about.html')
def feedback(request):
    return render(request,'feedback.html')
def vet(request):
    return render(request,'vet.html')
def Petra(request):
    return render(request,'Petra.html')
def taj(request):
    return render(request,'taj.html')
def ci(request):
    return render(request,'ci.html')
def mp(request):
    return render(request,'mp.html')
def cht(request):
    return render(request,'cht.html')
def christ(request):
    return render(request,'christ.html')



